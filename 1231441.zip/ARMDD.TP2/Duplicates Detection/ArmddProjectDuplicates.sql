-- Create schema if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'DuplicatesDetectionExample') 
    EXEC('CREATE SCHEMA DuplicatesDetectionExample');
	USE Bikes_StagingArea;


-- Truncate table if it exists, else create the table
IF OBJECT_ID('DuplicatesDetectionExample.ExistingPerson', 'U') IS NOT NULL
    TRUNCATE TABLE DuplicatesDetectionExample.ExistingPerson;
ELSE
    CREATE TABLE DuplicatesDetectionExample.ExistingPerson (
        [PersonType] [nvarchar](50) NOT NULL,
        [Title] [nvarchar](50) NOT NULL,
        [FirstName] [nvarchar](50) NOT NULL,
        [MiddleName] [nvarchar](50) NOT NULL,
        [LastName] [nvarchar](50) NOT NULL
    );
ALTER TABLE DuplicatesDetectionExample.ExistingPerson
ALTER COLUMN MiddleName NVARCHAR(50) NULL;


INSERT INTO DuplicatesDetectionExample.ExistingPerson
( [PersonType], [Title], [FirstName], [MiddleName], [LastName])
SELECT
     [PersonType], [Title], [FirstName], [MiddleName], [LastName]
FROM
    [Bikes_StagingArea].[dbo].[Persons]
WHERE
    [Title] IS NOT NULL;

IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='DuplicatesDetectionExample' AND TABLE_NAME = 'ArrivingPerson') 
	TRUNCATE TABLE DuplicatesDetectionExample.ArrivingPerson
ELSE
	CREATE TABLE DuplicatesDetectionExample.ArrivingPerson (
	     
		
        PersonType nvarchar(50) NOT NULL,
        Title nvarchar(50) NOT NULL,
        FirstName  NVARCHAR(50),
        MiddleName  NVARCHAR(50),
        LastName NVARCHAR(50)
		)

INSERT INTO DuplicatesDetectionExample.ArrivingPerson VALUES 	('Individual Customer','Mr.','David','R.','Robinett'),
							( 'Individual Customer', 'Ms.', 'Rebecca', 'A.', 'Robinson')													
						
-- DuplicatesBetweenSources table
IF OBJECT_ID('DuplicatesDetectionExample.DuplicatesBetweenSources', 'U') IS NOT NULL
    TRUNCATE TABLE DuplicatesDetectionExample.DuplicatesBetweenSources;
ELSE
    CREATE TABLE DuplicatesDetectionExample.DuplicatesBetweenSources (
        
        [PersonType (Input)] nvarchar(50),
        [Title(Input)] nvarchar(50) ,
        [FirstName (Input)] NVARCHAR(50),
        [MiddleName (Input)] NVARCHAR(50),
        [LastName (Input)] NVARCHAR(50),
        [PersonType (Matched)] nvarchar(50) ,
        [Title (Matched)] nvarchar(50) ,
        [FirstName (Matched)] NVARCHAR(50),
        [MiddleName (Matched)] NVARCHAR(50),
        [LastName (Matched)] NVARCHAR(50),
        [_Similarity] REAL,
        [_Similarity_PersonType] REAL,
        [_Similarity_Title] REAL,
        [_Similarity_FirstName] REAL,
        [_Similarity_MiddleName] REAL,
        [_Similarity_LastName] REAL
    );

-- NewCustomers table
IF OBJECT_ID('DuplicatesDetectionExample.NewPerson', 'U') IS NOT NULL
    TRUNCATE TABLE DuplicatesDetectionExample.NewPerson;
ELSE
    CREATE TABLE DuplicatesDetectionExample.NewPerson (
        [_key_in] INT,
        [_key_out] INT,
        [PersonType] nvarchar(50) ,
        [Title] nvarchar(50) ,
        [FirstName] NVARCHAR(50),
        [MiddleName] NVARCHAR(50),
        [LastName] NVARCHAR(50)
    );

-- DuplicatesInsideSource table
IF OBJECT_ID('DuplicatesDetectionExample.DuplicatesInsideSource', 'U') IS NOT NULL
    TRUNCATE TABLE DuplicatesDetectionExample.DuplicatesInsideSource;
ELSE
    CREATE TABLE DuplicatesDetectionExample.DuplicatesInsideSource (
        [_key_in] INT,
        [_key_out] INT,
        [PersonType] nvarchar(50) ,
        [Title] nvarchar(50) ,
        [FirstName] NVARCHAR(50),
        [MiddleName] NVARCHAR(50),
        [LastName] NVARCHAR(50),
		[PersonType_clean] nvarchar(50) ,
        [Title_clean] nvarchar(50) ,
        [FirstName_clean] NVARCHAR(50),
        [MiddleName_clean] NVARCHAR(50),
        [LastName_clean] NVARCHAR(50),
        [_Similarity] REAL,
		[_Similarity_PersonType] REAL,
        [_Similarity_Title] REAL,
        [_Similarity_FirstName] REAL,
		[_Similarity_MiddleName] REAL,
        [_Similarity_LastName] REAL,
    
    );









