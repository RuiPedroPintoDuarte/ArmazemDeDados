IF NOT EXISTS (SELECT name FROM sys.tables WHERE name = 'FactSales')
    CREATE TABLE FactSales (
        OrderDateKey INT NOT NULL,
        DueDateKey INT NOT NULL,
        ShipDateKey INT NOT NULL,
        CustomerKey INT NOT NULL,
        ProductKey INT NOT NULL,
        ShipMethodKey INT NOT NULL,
        ShipToAddresseKey INT NOT NULL,
		BillToAddresseKey INT NOT NULL,
        SalesTerritoriesKey INT NOT NULL,
        CurrencyKey INT NOT NULL,
        SalesPersonKey INT NOT NULL,
        SalesOrderID INT NOT NULL,
		SalesOrderDetailID INT NOT NULL,
        UnitPriceDiscount MONEY NOT NULL,
        OrderQty SMALLINT NOT NULL,
        UnitPrice MONEY NOT NULL,
		LineTotal NUMERIC(38,6) NOT NULL,
		SubTotalPerLine MONEY NOT NULL,
		TaxAmountPerLine MONEY NOT NULL,
		FreightPerLine MONEY NOT NULL,
		TotalDuePerLine MONEY NOT NULL
		Primary key(OrderDateKey, DueDateKey, ShipDateKey, CustomerKey, 
		SalesPersonKey, ProductKey, ShipMethodKey, SalesTerritoriesKey, 
		ShipToAddresseKey, BillToAddresseKey, CurrencyKey)
    )
