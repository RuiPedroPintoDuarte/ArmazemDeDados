IF NOT EXISTS (SELECT name FROM sys.tables WHERE name = 'DimSalesPerson')
begin
		CREATE TABLE [dbo].[DimSalesPerson](
		[SalesPersonKey] [int] IDENTITY(1,1) NOT NULL,
		[SalesPersonID] [int] NOT NULL,
		[FirstName] [nvarchar](50) NOT NULL,
		[MiddleName] [nvarchar](50) NULL,
		[LastName] [nvarchar](50) NOT NULL,
		[PersonType] [nvarchar](20) NOT NULL,
		[NationalIDNumber] [nvarchar](15) NOT NULL,
		[LoginID] [nvarchar](256) NOT NULL,
		[JobTitle] [nvarchar](50) NOT NULL,
		[Title] [nvarchar](50) NOT NULL,
		[BirhtDateKey] [int] NOT NULL,
		[MaritalStatus] [nvarchar](50) NOT NULL,
		[Gender] [nvarchar](50) NOT NULL,
		[HireDateKey] [int] NOT NULL,
		[SalariedFlag] [bit] NOT NULL,
		[VacationHours] [smallint] NOT NULL,
		[SickLeaveHours] [smallint] NOT NULL,
		[SalesQuota] [money] NULL,
		[Bonus] [money] NOT NULL,
		[ComissionPct] [smallmoney] NOT NULL,
		[SalesYTD] [money] NOT NULL,
		[SalesLastYear] [money] NOT NULL,
		[EffectiveDate] [datetime] NOT NULL,
		[ExpiredDate] [datetime] NULL,
		[IsCurrent] [nvarchar](3) NOT NULL,
	PRIMARY KEY CLUSTERED 
	(
		[SalesPersonKey] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
	) ON [PRIMARY]
	CREATE NONCLUSTERED INDEX [NonClusteredIndex-SalesPersonID] ON [dbo].[DimSalesPerson]
	(
		[SalesPersonID] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
END
