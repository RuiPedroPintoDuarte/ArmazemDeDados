IF NOT EXISTS (SELECT name FROM sys.tables WHERE name = 'FactCurrencyRate')
    CREATE TABLE FactCurrencyRate (
        DateKey INT NOT NULL,
        SourceCurrencyKey INT NOT NULL,
        DestinationCurrencyKey INT NOT NULL,
		CurrencyRateID INT NOT NULL,
        AverageRate DECIMAL(18, 2) NOT NULL,
        EndOfDayRate DECIMAL(18, 2) NOT NULL,
        PRIMARY KEY (DateKey, SourceCurrencyKey, DestinationCurrencyKey),
    )
