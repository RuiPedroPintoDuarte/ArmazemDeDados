IF NOT EXISTS (SELECT name FROM sys.tables WHERE name = 'FactSalesDQP')
	CREATE TABLE [dbo].[FactSalesDQP](
	[OrderDate] [date] NOT NULL,
	[DueDate] [date] NOT NULL,
	[ShipDate] [date] NOT NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NOT NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CurrencyCode] [nchar](3) NULL,
	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductNumber] [nvarchar](25) NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal] [numeric](38, 6) NOT NULL,
	[SubTotalPerLine] [money] NOT NULL,
	[TaxAmountPerLine] [money] NOT NULL,
	[FreightPerLine] [money] NOT NULL,
	[TotalDuePerLine] [money] NOT NULL,
	[CreatedDate] [date] NOT NULL,
	[ModifiedDate] [date] NOT NULL,
	[DQP] [nvarchar](100) NULL
) 
ELSE
	TRUNCATE TABLE FactSalesDQP