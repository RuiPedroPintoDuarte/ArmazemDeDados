SELECT 
    Persons.Title, 
    COUNT(Persons.Title) AS TitleCount
FROM 
    Bikes_StagingArea..Persons 
INNER JOIN 
    Bikes_StagingArea..Customers ON Persons.BusinessEntityID = Customers.PersonID
group by Persons.Title

SELECT 
    Title, COUNT(Title) AS TitleCount
FROM 
    Bikes_DataMart..DimCustomers
group by Title