SELECT MiddleName, COUNT(MiddleName)
FROM [Bikes_DataMart].[dbo].[DimCustomers]
Group by MiddleName

SELECT MiddleName, COUNT(MiddleName)
FROM [Bikes_StagingArea]..Persons p
INNER JOIN Bikes_StagingArea..Customers c ON p.BusinessEntityID=c.PersonID
Group by MiddleName